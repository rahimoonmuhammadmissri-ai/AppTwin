package com.missrirahimoon.apptwin

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val rv = findViewById<RecyclerView>(R.id.rvApps)
        rv.layoutManager = LinearLayoutManager(this)

        val apps = getLaunchableApps()
        rv.adapter = AppListAdapter(apps) { app ->
            onCloneRequested(app)
        }
    }

    /** Returns every user-launchable app on the device (system launcher apps excluded by default). */
    private fun getLaunchableApps(): List<AppInfo> {
        val pm = packageManager
        val launcherIntent = Intent(Intent.ACTION_MAIN, null).apply {
            addCategory(Intent.CATEGORY_LAUNCHER)
        }
        val resolvedApps = pm.queryIntentActivities(launcherIntent, 0)

        return resolvedApps
            .map { it.activityInfo.applicationInfo }
            .distinctBy { it.packageName }
            .filter { it.packageName != packageName } // don't list AppTwin itself
            .map { appInfo: ApplicationInfo ->
                AppInfo(
                    label = pm.getApplicationLabel(appInfo).toString(),
                    packageName = appInfo.packageName,
                    icon = pm.getApplicationIcon(appInfo)
                )
            }
            .sortedBy { it.label.lowercase() }
    }

    private fun onCloneRequested(app: AppInfo) {
        // NOTE: Real multi-instance "cloning" of a third-party app (running an
        // independent, isolated copy of Facebook/TikTok/YouTube on the same
        // device) requires an app-virtualization engine that sandboxes the
        // target APK's process, storage, and package identity. That engine is
        // a substantial separate module — see README.md in this project for
        // the recommended approach and next steps.
        Toast.makeText(
            this,
            "${app.label}: ${getString(R.string.clone_placeholder_msg)}",
            Toast.LENGTH_LONG
        ).show()
    }
}
