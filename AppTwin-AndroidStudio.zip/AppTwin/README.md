# AppTwin — By Missri Rahimoon

An Android Studio starter project for a "dual app / clone app" tool — the kind that lets
someone run a second, independent copy of an app (like having two WhatsApp or two TikTok
accounts on one phone).

## What's included (ready to build & run)
- Splash screen showing **"By Missri Rahimoon"**
- Home screen that lists every app installed on the device (name + icon), using
  Android's `PackageManager`
- A "Clone" button next to each app (currently shows a placeholder message —
  see below for why, and what to do next)

## How to open it
1. Open Android Studio → **Open** → select the `AppTwin` folder
2. Let Gradle sync
3. Run on a device/emulator (Android 7.0 / API 24 or higher)

## Why "Clone" doesn't fully work yet — and what real cloning requires
Actually running an independent, isolated copy of a third-party app (Facebook, TikTok,
YouTube, etc.) — without modifying or redistributing that app's code — needs an
**app-virtualization engine**. This is the same category of technology used by apps like
Parallel Space or App Cloner. In short, it:

1. Loads the target app's already-installed APK into a **sandboxed process** inside
   AppTwin (separate data directory, separate `SharedPreferences`/database storage, so
   the two copies don't interfere with each other)
2. Redirects that process's file I/O and storage paths to the sandbox instead of the
   real app's normal storage
3. Intercepts calls to `PackageManager`, `Context`, and similar system APIs so the
   cloned app doesn't realize it's running inside another app's process (a technique
   generally called "hooking")

This is a serious, separate engineering effort — realistically weeks of dedicated work,
not something to bolt onto a UI in one sitting. A few honest notes before you go further:

- **It's technically demanding.** Most working implementations lean on deep reflection
  and hooking (e.g. via the open-source **VirtualApp** project as a reference/base),
  and needs constant maintenance because each new Android version changes internal APIs.
- **Play Store policy risk.** Google's policies restrict apps that modify or interfere
  with how other apps run; a cloning app is a legitimate category (several exist on the
  Play Store today) but must be built carefully to stay compliant — for example, never
  bundling or redistributing another company's APK, and being transparent with users.
- **Recommended path:** build and test the virtualization module as its own isolated
  library first (separate from AppTwin's UI), verify it correctly runs one or two simple
  test apps end-to-end, and only then wire it into this UI via the `onCloneRequested()`
  function in `MainActivity.kt`.

## Project structure
```
AppTwin/
├── app/src/main/java/com/missrirahimoon/apptwin/
│   ├── SplashActivity.kt      # splash screen with credit line
│   ├── MainActivity.kt        # lists installed apps, handles Clone tap
│   ├── AppListAdapter.kt      # RecyclerView adapter
│   └── AppInfo.kt             # simple data model
├── app/src/main/res/
│   ├── layout/                # activity_splash.xml, activity_main.xml, item_app.xml
│   ├── values/                # strings.xml, colors.xml, themes.xml
│   └── mipmap-*/              # launcher icons
└── app/src/main/AndroidManifest.xml
```

## Next steps if you want to continue
1. Get the basic app running and confirm the installed-apps list works on your device
2. Decide on your target Android version range (older Android = easier hooking, less
   restricted; newer = more restrictions, more secure)
3. Prototype the sandboxing engine separately, test with 1 simple app before trying
   TikTok/Facebook/YouTube
4. Come back and I can help wire it in, or help with any single piece (icons, splash
   timing, list UI, permissions, etc.) as you build it out
