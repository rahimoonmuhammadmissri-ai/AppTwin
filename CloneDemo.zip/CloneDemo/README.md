# CloneDemo — By Missri Rahimoon

A tiny demo that shows the **real principle** behind "clone/dual apps" — using
a simple counter app that we own the source code for.

## What this proves
This project builds into **two separate APKs**:
- `CloneDemo` (package: `com.missrirahimoon.clonedemo`)
- `CloneDemo (Twin)` (package: `com.missrirahimoon.clonedemo.twin`)

Install both on the same phone — you'll see two separate app icons. Tap the
counter in each; they count **independently**, because Android treats them as
two completely different apps (different package name = different storage,
different everything).

## Why this technique can't clone Facebook/TikTok/etc.
This only works because **we have this app's source code** and can rebuild it
under a second package name. We don't have Facebook's or TikTok's source code
— nobody outside those companies does. To run two independent copies of an
app you don't own the source of, you'd need a full **virtualization engine**
(the approach used by Parallel Space, App Cloner, etc.), which:
- Sandboxes the target app's process, storage, and identity at runtime
- Requires deep reflection/hooking into Android internals
- Breaks with almost every new Android version and needs constant upkeep
- Mostly relies on old, unmaintained libraries (e.g. VirtualApp, abandoned
  since ~2019) that don't reliably work on modern Android (11+) anymore

## How to build & install both copies
Same GitHub Actions approach as the AppTwin project — push this to a repo
with a workflow that runs `gradle assembleOriginalDebug assembleTwinDebug`,
then download both APKs from the Artifacts and install them one at a time.
