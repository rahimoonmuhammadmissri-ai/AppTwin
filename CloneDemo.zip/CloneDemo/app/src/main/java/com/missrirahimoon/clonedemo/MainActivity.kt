package com.missrirahimoon.clonedemo

import android.content.Context
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private val prefsName = "clone_demo_prefs"
    private val countKey = "tap_count"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val tvAppName = findViewById<TextView>(R.id.tvAppName)
        val tvPackageName = findViewById<TextView>(R.id.tvPackageName)
        val tvCount = findViewById<TextView>(R.id.tvCount)
        val btnTap = findViewById<Button>(R.id.btnTap)

        tvAppName.text = getString(R.string.app_name)
        tvPackageName.text = packageName // proves which "copy" this is

        val prefs = getSharedPreferences(prefsName, Context.MODE_PRIVATE)
        var count = prefs.getInt(countKey, 0)
        tvCount.text = count.toString()

        btnTap.setOnClickListener {
            count++
            tvCount.text = count.toString()
            prefs.edit().putInt(countKey, count).apply()
        }
    }
}
