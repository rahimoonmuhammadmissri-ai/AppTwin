plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.missrirahimoon.clonedemo"
    compileSdk = 34

    defaultConfig {
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // Two "flavors" = two independently installable copies of the exact same app.
    // Android treats them as completely separate apps because their applicationId
    // (package name) differs — separate storage, separate SharedPreferences,
    // separate everything. This is the core trick: it works here because WE own
    // this app's source code and can rebuild it under a second package name.
    // It does NOT work for Facebook/TikTok/etc. because we don't have their source.
    flavorDimensions += "instance"
    productFlavors {
        create("original") {
            dimension = "instance"
            applicationId = "com.missrirahimoon.clonedemo"
            resValue("string", "app_name", "CloneDemo")
            resValue("color", "brand_color", "#5B3DF5")
        }
        create("twin") {
            dimension = "instance"
            applicationId = "com.missrirahimoon.clonedemo.twin"
            resValue("string", "app_name", "CloneDemo (Twin)")
            resValue("color", "brand_color", "#F5793D")
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }

    buildFeatures {
        viewBinding = true
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
}
